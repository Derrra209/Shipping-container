package tanks;

public class LargeTanker extends Truck {
    public LargeTanker() {
        super("Large Tanker", 860, 52);
    }
}