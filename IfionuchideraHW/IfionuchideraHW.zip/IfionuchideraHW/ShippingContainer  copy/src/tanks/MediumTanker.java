package tanks;

public class MediumTanker extends Truck {
    public MediumTanker() {
        super("Medium Tanker", 380, 40);
    }
}