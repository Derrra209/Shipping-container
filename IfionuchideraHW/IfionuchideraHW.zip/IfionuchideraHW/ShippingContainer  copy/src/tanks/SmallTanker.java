package tanks;

public class SmallTanker extends Truck {
    public SmallTanker() {
        super("Small Tanker", 300, 24);
    }
}